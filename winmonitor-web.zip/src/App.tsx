/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useRef } from "react";
import { Gauge } from "./components/Gauge";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";
import { Toaster, toast } from "sonner";
import {
  Settings,
  Activity,
  Cpu,
  Zap,
  Thermometer,
  AlertTriangle,
  Play,
  Pause,
  HardDrive,
  Download,
} from "lucide-react";
import { cn } from "./lib/utils";
import { getLocalHardwareInfo, type DetectedHardware } from "./lib/hardware-detection";
import { DownloadModal } from "./components/DownloadModal";

// Types
interface SystemStats {
  system: {
    manufacturer: string;
    model: string;
    version: string;
  };
  baseboard: {
    manufacturer: string;
    model: string;
    version: string;
  };
  os: {
    platform: string;
    distro: string;
    release: string;
    arch: string;
    hostname: string;
  };
  cpu: {
    manufacturer: string;
    brand: string;
    vendor: string;
    speed: number;
    speedMax: number;
    cores: number;
    physicalCores: number;
    load: number;
    temp: number;
    socket: string;
  };
  memory: {
    total: number;
    used: number;
    free: number;
    active: number;
  };
  gpu: {
    vendor: string;
    model: string;
    temperature: number;
    vram: number;
    memoryTotal?: number;
    memoryUsed?: number;
    utilizationGpu?: number;
  }[];
}

interface HistoryPoint {
  time: string;
  cpuLoad: number;
  cpuTemp: number;
  memUsed: number;
  gpuTemp: number;
}

const MAX_HISTORY = 300; // Keep last 300 points (10 minutes at 2s interval)

export default function App() {
  const [stats, setStats] = useState<SystemStats | null>(null);
  const [history, setHistory] = useState<HistoryPoint[]>([]);
  const [localHardware, setLocalHardware] = useState<DetectedHardware | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [thresholds, setThresholds] = useState({
    cpuTemp: 80,
    gpuTemp: 85,
  });
  const [showSettings, setShowSettings] = useState(false);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const lastAlertTime = useRef<number>(0);

  // Detect Hardware on Mount (only for basic platform info if needed, but we are removing model detection)
  useEffect(() => {
    const hw = getLocalHardwareInfo();
    setLocalHardware(hw);
  }, []);

  // Fetch or Generate Data
  useEffect(() => {
    if (isPaused) return;

    const fetchData = async () => {
      // Simulate realistic data
      const time = Date.now();
      // Sine wave + noise for realistic fluctuation
      const baseLoad = 30 + Math.sin(time / 5000) * 20;
      const baseTemp = 45 + Math.sin(time / 8000) * 15;
      
      // Random spikes
      const spike = Math.random() > 0.95 ? 30 : 0;

      const newStats: SystemStats = {
        system: {
          manufacturer: "",
          model: "",
          version: "",
        },
        baseboard: {
          manufacturer: "",
          model: "",
          version: "",
        },
        os: {
          platform: localHardware?.platform || "win32",
          distro: "",
          release: "",
          arch: "",
          hostname: "",
        },
        cpu: {
          manufacturer: "",
          brand: "",
          vendor: "",
          load: Math.min(100, Math.max(0, baseLoad + Math.random() * 10 + spike)),
          temp: Math.min(100, Math.max(30, baseTemp + Math.random() * 5 + (spike / 2))),
          cores: 0,
          physicalCores: 0,
          speed: 0,
          speedMax: 0,
          socket: "",
        },
        memory: {
          total: 0,
          used: 0,
          free: 0,
          active: 0,
        },
        gpu: [
          {
            vendor: "",
            model: "",
            temperature: Math.min(100, Math.max(35, baseTemp - 5 + Math.random() * 5)),
            vram: 0,
            memoryTotal: 0,
            memoryUsed: 0,
          },
        ],
      };

      setStats(newStats);

      // Update Title
      document.title = `WinMonitor - CPU: ${Math.round(newStats.cpu.temp)}°C | GPU: ${Math.round(newStats.gpu[0]?.temperature || 0)}°C`;

      // Update History
      setHistory((prev) => {
        const newPoint: HistoryPoint = {
          time: new Date().toLocaleTimeString([], { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" }),
          cpuLoad: newStats.cpu.load,
          cpuTemp: newStats.cpu.temp,
          memUsed: (newStats.memory.used / newStats.memory.total) * 100,
          gpuTemp: newStats.gpu[0]?.temperature || 0,
        };
        const newHistory = [...prev, newPoint];
        if (newHistory.length > MAX_HISTORY) newHistory.shift();
        return newHistory;
      });

      // Check Alerts (throttle to once every 10s)
      const now = Date.now();
      if (now - lastAlertTime.current > 10000) {
        if (newStats.cpu.temp > thresholds.cpuTemp) {
          toast.error(`High CPU Temperature: ${Math.round(newStats.cpu.temp)}°C`, {
            description: "Check cooling system immediately!",
            duration: 5000,
          });
          lastAlertTime.current = now;
        }
        if (newStats.gpu[0]?.temperature > thresholds.gpuTemp) {
          toast.error(`High GPU Temperature: ${Math.round(newStats.gpu[0].temperature)}°C`, {
            description: "GPU is running hot!",
            duration: 5000,
          });
          lastAlertTime.current = now;
        }
      }
    };

    const interval = setInterval(fetchData, 2000);
    fetchData(); // Initial call
    return () => clearInterval(interval);
  }, [isPaused, thresholds, localHardware]);

  // Helper for status color
  const getStatusColor = (val: number, limit: number) => {
    if (val >= limit) return "text-red-500";
    if (val >= limit * 0.8) return "text-yellow-500";
    return "text-emerald-500";
  };

  // Helper to find max value in history
  const getMaxMetric = (metric: keyof HistoryPoint) => {
    if (history.length === 0) return { value: 0, time: "--:--" };
    return history.reduce(
      (max, point) => ((point[metric] as number) > max.value ? { value: point[metric] as number, time: point.time } : max),
      { value: 0, time: "--:--" }
    );
  };

  // Helper to find min value in history
  const getMinMetric = (metric: keyof HistoryPoint) => {
    if (history.length === 0) return { value: 0, time: "--:--" };
    return history.reduce(
      (min, point) => ((point[metric] as number) < min.value || min.value === 0 ? { value: point[metric] as number, time: point.time } : min),
      { value: 100, time: "--:--" }
    );
  };

  const maxCpuTemp = getMaxMetric("cpuTemp");
  const minCpuTemp = getMinMetric("cpuTemp");
  const maxGpuTemp = getMaxMetric("gpuTemp");
  const minGpuTemp = getMinMetric("gpuTemp");

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-emerald-500/30 flex flex-col">
      <Toaster position="top-right" theme="dark" />
      
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Activity className="w-6 h-6 text-emerald-500" />
            <h1 className="text-xl font-bold tracking-tight">WinMonitor <span className="text-zinc-500 font-mono text-sm ml-2">v1.0.0</span></h1>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsPaused(!isPaused)}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors text-zinc-400 hover:text-zinc-100"
            >
              {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
            </button>
            
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={cn(
                "p-2 hover:bg-zinc-800 rounded-lg transition-colors",
                showSettings ? "text-emerald-400 bg-emerald-500/10" : "text-zinc-400 hover:text-zinc-100"
              )}
            >
              <Settings className="w-5 h-5" />
            </button>

            <button
              onClick={() => setShowDownloadModal(true)}
              className="p-2 hover:bg-zinc-800 rounded-lg transition-colors text-zinc-400 hover:text-zinc-100"
              title="Download Windows App"
            >
              <Download className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <DownloadModal isOpen={showDownloadModal} onClose={() => setShowDownloadModal(false)} />

      {/* Settings Panel */}
      {showSettings && (
        <div className="bg-zinc-900 border-b border-zinc-800 p-6 animate-in slide-in-from-top-4 duration-200">
          <div className="max-w-7xl mx-auto">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Alert Thresholds
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="space-y-2">
                <label className="text-sm text-zinc-400 flex justify-between">
                  CPU Temp Alert
                  <span className="text-zinc-100 font-mono">{thresholds.cpuTemp}°C</span>
                </label>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={thresholds.cpuTemp}
                  onChange={(e) => setThresholds({ ...thresholds, cpuTemp: Number(e.target.value) })}
                  className="w-full accent-emerald-500 h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-zinc-400 flex justify-between">
                  GPU Temp Alert
                  <span className="text-zinc-100 font-mono">{thresholds.gpuTemp}°C</span>
                </label>
                <input
                  type="range"
                  min="50"
                  max="100"
                  value={thresholds.gpuTemp}
                  onChange={(e) => setThresholds({ ...thresholds, gpuTemp: Number(e.target.value) })}
                  className="w-full accent-emerald-500 h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="max-w-7xl mx-auto p-4 md:p-6 space-y-6 flex-1 w-full">
        {/* CPU Section */}
        <section className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500/10 rounded-lg">
                <Cpu className="w-6 h-6 text-emerald-500" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Processor (CPU)</h2>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-zinc-500 uppercase tracking-wider">Status</p>
              <p className={cn("font-bold", getStatusColor(stats?.cpu.temp || 0, thresholds.cpuTemp))}>
                {(stats?.cpu.temp || 0) > thresholds.cpuTemp ? "OVERHEATING" : "NORMAL"}
              </p>
              <div className="mt-2 text-xs grid grid-cols-2 gap-x-4">
                <div>
                  <p className="text-zinc-500 uppercase tracking-wider">Max (10m)</p>
                  <p className="font-mono text-zinc-300">
                    {Math.round(maxCpuTemp.value)}°C <span className="text-zinc-600">@ {maxCpuTemp.time}</span>
                  </p>
                </div>
                <div>
                  <p className="text-zinc-500 uppercase tracking-wider">Min (10m)</p>
                  <p className="font-mono text-zinc-300">
                    {Math.round(minCpuTemp.value)}°C <span className="text-zinc-600">@ {minCpuTemp.time}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Gauge
              value={stats?.cpu.temp || 0}
              max={100}
              label="Temperature"
              unit="°C"
              threshold={thresholds.cpuTemp}
              className="md:border-r border-zinc-800"
            />
            <Gauge
              value={stats?.cpu.load || 0}
              max={100}
              label="Utilization"
              unit="%"
              threshold={90}
              className="md:border-r border-zinc-800"
            />
            <div className="h-[160px] w-full">
              <p className="text-xs text-zinc-500 mb-2 text-center uppercase tracking-wider">Temp History (10m)</p>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis 
                    dataKey="time" 
                    tick={{ fill: '#71717a', fontSize: 10 }}
                    minTickGap={30}
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    tick={{ fill: '#71717a', fontSize: 10 }}
                    unit="°C"
                    width={30}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#18181b", borderColor: "#27272a", color: "#f4f4f5" }}
                    itemStyle={{ color: "#f97316" }}
                    labelStyle={{ display: "none" }}
                    formatter={(value: number) => [`${Math.round(value)}°C`, "Temp"]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="cpuTemp" 
                    stroke="#f97316" 
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* GPU Section */}
        <section className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-500/10 rounded-lg">
                <Zap className="w-6 h-6 text-purple-500" />
              </div>
              <div>
                <h2 className="text-lg font-bold">Graphics (GPU)</h2>
              </div>
            </div>
            <div className="text-right">
              <p className="text-xs text-zinc-500 uppercase tracking-wider">Status</p>
              <p className={cn("font-bold", getStatusColor(stats?.gpu[0]?.temperature || 0, thresholds.gpuTemp))}>
                {(stats?.gpu[0]?.temperature || 0) > thresholds.gpuTemp ? "OVERHEATING" : "NORMAL"}
              </p>
              <div className="mt-2 text-xs grid grid-cols-2 gap-x-4">
                <div>
                  <p className="text-zinc-500 uppercase tracking-wider">Max (10m)</p>
                  <p className="font-mono text-zinc-300">
                    {Math.round(maxGpuTemp.value)}°C <span className="text-zinc-600">@ {maxGpuTemp.time}</span>
                  </p>
                </div>
                <div>
                  <p className="text-zinc-500 uppercase tracking-wider">Min (10m)</p>
                  <p className="font-mono text-zinc-300">
                    {Math.round(minGpuTemp.value)}°C <span className="text-zinc-600">@ {minGpuTemp.time}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Gauge
              value={stats?.gpu[0]?.temperature || 0}
              max={100}
              label="Temperature"
              unit="°C"
              threshold={thresholds.gpuTemp}
              className="md:border-r border-zinc-800"
            />
            <div className="h-[160px] w-full">
              <p className="text-xs text-zinc-500 mb-2 text-center uppercase tracking-wider">Temp History (10m)</p>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                  <XAxis 
                    dataKey="time" 
                    tick={{ fill: '#71717a', fontSize: 10 }}
                    minTickGap={30}
                  />
                  <YAxis 
                    domain={[0, 100]} 
                    tick={{ fill: '#71717a', fontSize: 10 }}
                    unit="°C"
                    width={30}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#18181b", borderColor: "#27272a", color: "#f4f4f5" }}
                    itemStyle={{ color: "#a855f7" }}
                    labelStyle={{ display: "none" }}
                    formatter={(value: number) => [`${Math.round(value)}°C`, "Temp"]}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="gpuTemp" 
                    stroke="#a855f7" 
                    strokeWidth={2}
                    dot={false}
                    isAnimationActive={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        {/* Memory Section Removed */}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800 bg-zinc-900/50 p-4 text-xs text-zinc-500 font-mono flex justify-between items-center">
        <div>
          WinMonitor v1.0.0 &bull; Live Monitoring
        </div>
      </footer>
    </div>
  );
}

