import { X, Cpu, Zap, HardDrive, ShieldAlert } from "lucide-react";

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function InfoModal({ isOpen, onClose }: InfoModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-emerald-500" />
            Hardware Detection Limitations
          </h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-zinc-800 rounded-full transition-colors text-zinc-400 hover:text-zinc-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 text-blue-200 text-sm">
            <p className="font-semibold mb-1">Why can't I see my exact hardware?</p>
            <p className="opacity-80">
              Modern web browsers run in a secure "sandbox" that strictly limits access to your computer's hardware details. 
              This prevents websites from "fingerprinting" (tracking) you based on your unique hardware components.
            </p>
          </div>

          <div className="grid gap-4">
            <div className="flex gap-4 p-4 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className="p-2 bg-zinc-900 rounded-lg h-fit">
                <Cpu className="w-5 h-5 text-zinc-400" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-200 mb-1">CPU Model</h3>
                <p className="text-sm text-zinc-400 mb-2">
                  <span className="text-red-400 font-mono text-xs uppercase border border-red-400/20 bg-red-400/10 px-1.5 py-0.5 rounded mr-2">Blocked</span>
                  Browsers do not expose the CPU model name (e.g., "i9-14900K").
                </p>
                <p className="text-xs text-zinc-500">
                  We can only detect the <strong>logical core count</strong> (Threads). We use this to guess a generic name, or you can set it manually in Settings.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className="p-2 bg-zinc-900 rounded-lg h-fit">
                <Zap className="w-5 h-5 text-zinc-400" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-200 mb-1">GPU & VRAM</h3>
                <p className="text-sm text-zinc-400 mb-2">
                  <span className="text-yellow-400 font-mono text-xs uppercase border border-yellow-400/20 bg-yellow-400/10 px-1.5 py-0.5 rounded mr-2">Partial</span>
                  Model name sometimes detectable. VRAM is <strong>never</strong> exposed.
                </p>
                <p className="text-xs text-zinc-500">
                  Browsers completely hide VRAM size. We default to 12GB for simulation. You <strong>must</strong> set your actual VRAM size in Settings for accurate usage percentages.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className="p-2 bg-zinc-900 rounded-lg h-fit">
                <HardDrive className="w-5 h-5 text-zinc-400" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-200 mb-1">System RAM</h3>
                <p className="text-sm text-zinc-400 mb-2">
                  <span className="text-yellow-400 font-mono text-xs uppercase border border-yellow-400/20 bg-yellow-400/10 px-1.5 py-0.5 rounded mr-2">Approximate</span>
                  Capped at 8GB in most browsers.
                </p>
                <p className="text-xs text-zinc-500">
                  The <code>navigator.deviceMemory</code> API is imprecise and usually capped at 8GB to prevent fingerprinting. If you have 16GB, 32GB, or more, the browser will likely report "8GB". Use Settings to set your actual RAM.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className="p-2 bg-zinc-900 rounded-lg h-fit">
                <Thermometer className="w-5 h-5 text-zinc-400" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-200 mb-1">Real-Time Stats (Temp/Load)</h3>
                <p className="text-sm text-zinc-400 mb-2">
                  <span className="text-red-400 font-mono text-xs uppercase border border-red-400/20 bg-red-400/10 px-1.5 py-0.5 rounded mr-2">Impossible</span>
                  Web pages cannot read hardware sensors.
                </p>
                <p className="text-xs text-zinc-500">
                  Temperature, voltage, and fan speeds are completely inaccessible to web apps for security. The data shown here is a <strong>simulation</strong> for demonstration purposes.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-zinc-800 bg-zinc-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-100 text-zinc-900 font-semibold rounded-lg hover:bg-zinc-200 transition-colors"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
}
