import React from "react";
import { cn } from "../lib/utils";

interface GaugeProps {
  value: number;
  max?: number;
  label: string;
  unit?: string;
  size?: number;
  threshold?: number;
  className?: string;
}

export function Gauge({
  value,
  max = 100,
  label,
  unit = "%",
  size = 120,
  threshold = 80,
  className,
}: GaugeProps) {
  const radius = size / 2 - 10;
  const circumference = 2 * Math.PI * radius;
  const progress = Math.min(Math.max(value / max, 0), 1);
  const offset = circumference - progress * circumference;

  const isHigh = value >= threshold;
  const color = isHigh ? "text-red-500" : "text-emerald-500";
  const strokeColor = isHigh ? "#ef4444" : "#10b981";

  return (
    <div className={cn("flex flex-col items-center", className)}>
      <div className="relative" style={{ width: size, height: size }}>
        {/* Background Circle */}
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            className="text-zinc-800"
          />
          {/* Progress Circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={strokeColor}
            strokeWidth="8"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
            className="transition-all duration-500 ease-out"
          />
        </svg>
        {/* Center Text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={cn("text-2xl font-bold font-mono", color)}>
            {Math.round(value)}
            <span className="text-sm ml-0.5">{unit}</span>
          </span>
        </div>
      </div>
      <span className="mt-2 text-xs font-medium uppercase tracking-wider text-zinc-400">
        {label}
      </span>
    </div>
  );
}
