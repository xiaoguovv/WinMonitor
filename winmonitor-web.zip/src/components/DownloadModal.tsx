import { X, Download, Terminal, Package } from "lucide-react";

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DownloadModal({ isOpen, onClose }: DownloadModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-zinc-800 flex justify-between items-center bg-zinc-900/50">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <Download className="w-6 h-6 text-emerald-500" />
            Download Windows App (.exe)
          </h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-zinc-800 rounded-full transition-colors text-zinc-400 hover:text-zinc-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-6 space-y-6 overflow-y-auto max-h-[70vh]">
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 text-blue-200 text-sm">
            <p className="font-semibold mb-1">Running in Cloud Container</p>
            <p className="opacity-80">
              This app is running in a secure web container. We cannot generate downloadable .exe files directly from here.
              However, the project is fully configured for Electron!
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-zinc-200">How to Build Locally</h3>
            
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 font-mono text-sm space-y-4">
              <div>
                <p className="text-zinc-500 mb-2"># 1. Clone the repository</p>
                <div className="bg-zinc-900 p-3 rounded-lg text-emerald-400 select-all">
                  git clone &lt;your-repo-url&gt;<br/>
                  cd winmonitor
                </div>
              </div>

              <div>
                <p className="text-zinc-500 mb-2"># 2. Install dependencies</p>
                <div className="bg-zinc-900 p-3 rounded-lg text-emerald-400 select-all">
                  npm install
                </div>
              </div>

              <div>
                <p className="text-zinc-500 mb-2"># 3. Build Windows Installer</p>
                <div className="bg-zinc-900 p-3 rounded-lg text-emerald-400 select-all">
                  npm run electron:build
                </div>
              </div>
            </div>

            <div className="flex gap-4 p-4 bg-zinc-950/50 rounded-xl border border-zinc-800/50">
              <div className="p-2 bg-zinc-900 rounded-lg h-fit">
                <Package className="w-5 h-5 text-zinc-400" />
              </div>
              <div>
                <h3 className="font-semibold text-zinc-200 mb-1">Output</h3>
                <p className="text-sm text-zinc-400">
                  The installer (<code>WinMonitor Setup 1.0.0.exe</code>) will be created in the <code>dist-electron</code> folder.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-zinc-800 bg-zinc-900/50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-100 text-zinc-900 font-semibold rounded-lg hover:bg-zinc-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
