export interface DetectedHardware {
  gpuRenderer: string;
  gpuVendor: string;
  cpuThreads: number;
  memoryApprox: number;
  userAgent: string;
  platform: string;
  isMobile: boolean;
}

export function getLocalHardwareInfo(): DetectedHardware {
  const info: DetectedHardware = {
    gpuRenderer: "Unknown GPU",
    gpuVendor: "Unknown Vendor",
    cpuThreads: 0,
    memoryApprox: 0,
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    isMobile: /Mobi|Android/i.test(navigator.userAgent),
  };

  // 1. Detect CPU Threads
  if (typeof navigator !== "undefined" && "hardwareConcurrency" in navigator) {
    info.cpuThreads = navigator.hardwareConcurrency;
  }

  // 2. Detect Memory (Chrome/Edge only, approximate)
  // @ts-ignore - deviceMemory is non-standard but supported in Chromium
  if (typeof navigator !== "undefined" && "deviceMemory" in navigator) {
    // @ts-ignore
    info.memoryApprox = navigator.deviceMemory;
  }

  // 3. Detect GPU via WebGL
  try {
    const canvas = document.createElement("canvas");
    const gl =
      canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
    if (gl) {
      const debugInfo = (gl as WebGLRenderingContext).getExtension(
        "WEBGL_debug_renderer_info"
      );
      if (debugInfo) {
        info.gpuRenderer = (gl as WebGLRenderingContext).getParameter(
          debugInfo.UNMASKED_RENDERER_WEBGL
        );
        info.gpuVendor = (gl as WebGLRenderingContext).getParameter(
          debugInfo.UNMASKED_VENDOR_WEBGL
        );
      }
    }
  } catch (e) {
    console.error("WebGL detection failed", e);
  }

  return info;
}
